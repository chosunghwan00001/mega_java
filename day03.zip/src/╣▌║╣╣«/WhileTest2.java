package 반복문;

public class WhileTest2 {

	public static void main(String[] args) {
		//무한루프(계속반복)
		while(true) {
			System.out.println("무한루프");
		}
	}

}
