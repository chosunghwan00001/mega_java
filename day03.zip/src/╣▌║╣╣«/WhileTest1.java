package 반복문;

public class WhileTest1 {

	public static void main(String[] args) {
		int num =3;//시작값
		while(num < 5) {//조건
			System.out.println("환영합니다.");
			//num = num+1;
			num++; //증감값
		}
	}

}
