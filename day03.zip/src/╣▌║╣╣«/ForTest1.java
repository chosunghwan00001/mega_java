package 반복문;

public class ForTest1 {

	public static void main(String[] args) {
		//초기값, 조건식, 증감값
		for (int i = 0; i < 10; i++) {
			System.out.println("＠");
		}
	}

}
