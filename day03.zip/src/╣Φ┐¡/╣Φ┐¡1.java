package 배열;

public class 배열1 {

	public static void main(String[] args) {
		//배열-> 참조형
		//참조(레퍼런스)=참고
		//참조형은 값이 저장된 주소값을 변수에 저장된다.
		int[] num = { 1, 2, 3, 4, 5 };
		System.out.println(num);//주소값
		//정수-> 기본형
		//기본형은 타입에 맞는 값이 변수에 저장된다.
		int num2 = 3;
		System.out.println(num2);//
	}

}
