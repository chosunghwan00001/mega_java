package 배열;

public class 배열3 {

	public static void main(String[] args) {
		
		int[] num = new int[3];
		num[0] = 1;
		num[1] = 2;
		num[2] = 3;

	}

}
