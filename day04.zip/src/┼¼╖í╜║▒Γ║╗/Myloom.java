package 클래스기본;

public class Myloom {

	public static void main(String[] args) {
		Phone p1 = new Phone();
		p1.shape = "네모";
		p1.size = 9;
		
		p1.call();
		p1.kakao();

	}

}
