package 클래스기본;

public class Dog {
	//클래스는 메인 없음 조립하기 위해서
	//정적
	String shape;
	int size;
	//동적
	public void call() {
		System.out.println("멍멍");
	}
	
}
