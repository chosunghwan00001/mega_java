package 클래스기본;

public class 계산기사용 {

	public static void main(String[] args) {
		계산기 cal = new 계산기();
		cal.add(300,200);
		cal.minus(300,200);
		cal.mul(300,200);
		cal.div(300,200);

	}

}
