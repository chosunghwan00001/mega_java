package 클래스기본;

public class 계산기2 {

	//void : 할일을 하고 반환값이 없다. 즉 밥통에서 취사버튼를 누르면 밥만 한다.
	//리턴이 있는건 취사버튼 누르면 취사를 시작합니다. 메시지 리턴 그리고 밥한다
	public int mul(int n1, int n2) {
		return n1*n2;
		
	}

	
}
