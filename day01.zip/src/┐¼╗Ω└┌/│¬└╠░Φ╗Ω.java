package 연산자;

public class 나이계산 {

	public static void main(String[] args) {
		int year = 1983;
		int age = 2019-year+1;
		System.out.println("나이는??" + age);
		
	}

}
