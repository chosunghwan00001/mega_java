package 변수;

public class Hi {

	public static void main(String[] args) {
		//이름
		//소속
		//나이
		System.out.println("조성환");
		System.out.println("회사소속");
		System.out.println("37");
	}

}
