package 변수;

public class House {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String text1 = "저의 집에 대한 정보 입니다.";
		String text2 = "-------------------------------------------------";
		
		String jibung = "초록";
		String tel = "8441234";
		int hosu = 302;
		int floor = 10;
		double window = 50.5;
		char 	location = '좌';
		boolean cool = true;
		
		System.out.println(text2);
		System.out.println(text1);
		System.out.println(text2);
		System.out.println("집지붕색깔은? " + jibung);
		System.out.println("집전화번호는? " + tel);
		System.out.println("호실은? " + hosu);
		System.out.println("층수는? " + floor);
		System.out.println("창문크기는? " + window);
		System.out.println("집위치는? " + location);
		System.out.println("집이 시원합니까? " + cool);
		System.out.println(text2);

	}

}
