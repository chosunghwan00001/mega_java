package 변수;

public class Hello {

	public static void main(String[] args) {
		// main에서 시작
		System.out.println("헬로우 월드");
		System.out.println("나는 프로그래머"); 
		//컨트롤+f11 = 실행
		
		//자동완성 단축키
		//키워드 + 컨트롤 + 스페이스
		System.out.println("나는 자바프로그래머"); // sysout+컨트롤+스페이스
		
	}

}
