package 순차문;

public class 순차처리확인 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println(100+100+"");
		//System.out.println("두번째날입니다.");
		
		
		int number = 360;
		String company = "빨라운송";
		double late = 0.5;
		char color = 'r';
		String temp = "*************************";
		String temp1 = "------------------------";
		
		System.out.println(temp);
		System.out.println("둘째날 입니다.");
		System.out.println(temp1);
		System.out.println("내 버스번호 " + number);
		System.out.println("버스회사이름 " + company);
		System.out.println("늦은시간 " + late);
		System.out.println("버스색상 " + color);
		System.out.println(temp1);
		
		
	}

}
