package 조건문;

import java.util.Random;

public class 주민번호 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 일괄주석및일괄주석풀기 컨트롤+슬러쉬
		Random r = new Random();
		System.out.println(r.nextInt(3));// 0~2까지 발생
		System.out.println(r.nextInt(3));// 0~2까지 발생
		System.out.println(r.nextInt(3));// 0~2까지 발생
	}

}
